#ifndef MYBASE_H
#define MYBASE_H

#include "base.h"
class myBase : public Base
{
public:
    myBase();
    myBase(int x,int y);
private:

};

#endif // MYBASE_H
