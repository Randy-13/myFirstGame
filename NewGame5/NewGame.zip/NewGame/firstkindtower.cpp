#include "firstkindtower.h"

firstKindTower::firstKindTower()
{

}
