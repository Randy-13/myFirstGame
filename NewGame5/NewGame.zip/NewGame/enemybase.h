#ifndef ENEMYBASE_H
#define ENEMYBASE_H

#include "base.h"
class enemyBase : public Base
{
public:
    enemyBase();
    enemyBase(int x,int y);
private:
};

#endif // ENEMYBASE_H
