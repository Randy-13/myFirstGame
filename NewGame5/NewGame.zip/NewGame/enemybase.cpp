#include "enemybase.h"

enemyBase::enemyBase() : Base()
{

}

enemyBase::enemyBase(int x,int y) : Base(x,y)
{

}
