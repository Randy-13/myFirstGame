#ifndef BASE_H
#define BASE_H


class Base
{
public:
    Base();
    Base(int x,int y);
    int getX();
    int getY();
private:
    int x;
    int y;
};

#endif // BASE_H
