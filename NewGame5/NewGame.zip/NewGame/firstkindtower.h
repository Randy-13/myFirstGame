#ifndef FIRSTKINDTOWER_H
#define FIRSTKINDTOWER_H

#include "tower.h"
#include <QString>
class firstKindTower : Tower
{
public:
    firstKindTower();
private:
    QString picturePath;
};

#endif // FIRSTKINDTOWER_H
