#include "mybase.h"

myBase::myBase() : Base()
{

}

myBase::myBase(int x,int y) : Base(x,y)
{

}

